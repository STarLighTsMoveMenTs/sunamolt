package bot.molt.android.gateway

const val GATEWAY_PROTOCOL_VERSION = 3

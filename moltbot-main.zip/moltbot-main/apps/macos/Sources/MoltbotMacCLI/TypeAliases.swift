import MoltbotKit
import MoltbotProtocol

typealias ProtoAnyCodable = MoltbotProtocol.AnyCodable
typealias KitAnyCodable = MoltbotKit.AnyCodable
